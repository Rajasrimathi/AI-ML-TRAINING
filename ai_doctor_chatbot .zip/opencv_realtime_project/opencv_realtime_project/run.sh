
#!/usr/bin/env bash
set -e
python src/face_detection.py --camera 0
